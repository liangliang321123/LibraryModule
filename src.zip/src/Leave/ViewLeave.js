const ViewLeave = () => {
    return(
        <div>
            <h2>View Leave</h2>
        </div>
    )
}
export default ViewLeave